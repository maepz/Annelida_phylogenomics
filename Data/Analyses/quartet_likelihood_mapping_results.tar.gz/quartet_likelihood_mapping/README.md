# Quartet-likelihood-mapping archive

This archive contains the IQ-TREE reports and quartet-definition files used
for the quartet-likelihood-mapping analyses reported in the manuscript and
supplementary materials. It includes the analyses of Oweniidae, Sipuncula,
Myzostomida, Clitellata, Cirratuliformia, Siboglinidae, and their combined
placements.

The files record the original analysis outputs and are provided for
methodological transparency rather than as a turnkey reproducibility
workflow. Original filenames are retained so that they remain traceable to
the analysis and figure-generation code.

## Contents

- `reports/site_homogeneous/` contains 43 IQ-TREE reports from the
  edge-proportional partitioned analyses (`EDGEPROP`; `{MAT}+I+G4`).
- `reports/site_heterogeneous/` contains 40 IQ-TREE reports from the
  site-heterogeneous analyses (`SITEHET2`; `LG+C60+F+G4`).
- `quartet_definitions/` contains 36 NEXUS files defining the taxon groups
  sampled in the quartet analyses.
- `MANIFEST.tsv` lists every archived file, its size, and its SHA-256
  checksum.

Dataset identifiers in the filenames include `SOGall`, `SOG10_tax_occ`,
`A31_fullcov`, `L38_synt`, `L42_synt`, and `NP_synt`. Not every focal
analysis was run for every matrix or model.

## Path sanitization

One site-homogeneous A31 report contained the original server path in its
partition-file metadata and suggested AliSim command:

`EDGEPROP.quartet.quartet_map_3.A31_fullcov_SibCir_quartets.iqtree`

In the archived copy, the server prefix was replaced with
`<ANALYSIS_ROOT>`. No numerical result, quartet table, model parameter, or
other analysis output was changed. The source files outside the repository
were not modified.

The cleaned parsing workflow for the Oweniidae and Sipuncula species-level
summaries is provided as
`Scripts/Hypothesis_testing/Parse_QuartetLikelihoodMapping_results.ipynb`.
